print("Hello, világ!")
